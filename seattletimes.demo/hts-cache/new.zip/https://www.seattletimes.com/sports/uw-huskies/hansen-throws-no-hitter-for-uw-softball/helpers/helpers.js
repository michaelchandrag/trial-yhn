<!DOCTYPE html>
<html class="no-js" lang="en-US" itemscope>

  <head>
      <link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png?v=7kovnr5xE4">
  <link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png?v=7kovnr5xE4">
  <link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png?v=7kovnr5xE4">
  <link rel="manifest" href="/site.webmanifest?v=7kovnr5xE4">
  <link rel="mask-icon" href="/safari-pinned-tab.svg?v=7kovnr5xE4" color="#5bbad5">
  <link rel="shortcut icon" href="/favicon.ico?v=7kovnr5xE4">
  <meta name="msapplication-TileColor" content="#2b5797">
  <meta name="theme-color" content="#ffffff">

  
  <link rel="preconnect" href="https://www.google.com">
  <link rel="preconnect" href="https://www.gstatic.com" crossorigin>
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <meta name="robots" content="max-image-preview:large">
  <meta name="twitter:widgets:autoload" content="off">

        <link rel='preload' href='https://www.googletagmanager.com/gtm.js?id=GTM-KDZ92J' as='script' fetchpriority='low'>
      <link rel='preload' href='//static.chartbeat.com/js/chartbeat_mab.js' as='script' fetchpriority='high'>
            <link rel="preload" href="https://htlbid.com/v3/seattletimes.com/htlbid.css" as="style" fetchpriority='low'>
      <link rel="preload" href="https://htlbid.com/v3/seattletimes.com/htlbid.js" as="script" fetchpriority='low'>
      <link rel='stylesheet' type='text/css' href='https://htlbid.com/v3/seattletimes.com/htlbid.css'>
        <script>
      window.SEATIMESCO = window.SEATIMESCO || {};
      window.SEATIMESCO.noThirdPartyScripts = false;
    </script>
     <link rel='preload' href='//use.typekit.net/lty1dar.css' as='font'>
  <link rel='preload' href='/wp-content/themes/st_refresh/css/fonts/icons-st.woff?1642194637932' as='font' fetchpriority='high' type='font/woff2' crossorigin>
  <link rel='stylesheet' href='//use.typekit.net/lty1dar.css' onLoad='document.getElementsByTagName("html")[0].classList.add("wf-active")' fetchpriority='high'>

  
  <!-- Echobox Preload -->
  <link rel='preload' href='https://applets.ebxcdn.com/ebx.js' as='script' fetchpriority='low'>


      <link rel='preload' href='https://cdn.cookielaw.org/scripttemplates/otSDKStub.js' as='script' fetchpriority='high'>
    <link rel='preload' href='https://cdn.cookielaw.org/opt-out/otCCPAiab.js' as='script' fetchpriority='high'>
  
  
  
  
  
  <title>Page not found | The Seattle Times</title>

  <meta name="robots" content="noarchive">
  
  
  <meta property="mrf:tags" content="contentType:404_page;internalTags:not-set;section_tier1:not-set;section_tier2:not-set;sections_all:not-set;source:not-set;imageCount:not-set;videoCount:not-set;template:not-set;galleryType:not-set;age:not-set;credit:not-set;paragraphCount:not-set;wordcount:not-set;graphicCount:not-set;hasTeaserImage:not-set;" />
  
  <meta property="og:image"        content="https://www.seattletimes.com/wp-content/themes/st_refresh/img/st-meta-facebook.png" />
  <meta property="og:image:height" content="200" />
  <meta property="og:image:width"  content="200" />

  <meta name="twitter:card"  content="summary" />
  <meta name="twitter:site"  content="@seattletimes" />
  <meta name="twitter:image" content="https://www.seattletimes.com/wp-content/themes/st_refresh/img/st-meta-twitter.png" />

    <meta name="description" content="What you were looking for wasn't found. Maybe we can help you figure out where to go." />

<meta property="fb:app_id" content="2618768518177469"/><meta property="fb:pages" content="38472826214" /><meta name="msvalidate.01" content="A8C10DCF8621D573190E61A9BB5E1782" />

  <script>
    // Header scripts that can't otherwise be placed lower in the page. Keep as minimal as possible.

    // Sets 'js' on html element and removes 'no-js' if present (here to prevent flashing)
    (function(){
    document.documentElement.className = document.documentElement.className.replace(/(^|\s)no-js(\s|$)/, '$1$2') + (' js ');
    })();
  </script>

  <script>
  window.SEATIMESCO.singleSignOn = window.SEATIMESCO.singleSignOn || {};
  window.SEATIMESCO.singleSignOn.info = window.SEATIMESCO.singleSignOn.info || {};
  window.SEATIMESCO.singleSignOn.info.ssoEnvironment          = "secure.";
  window.SEATIMESCO.singleSignOn.info.subscriberSessionURL    = "https://secure.seattletimes.com/accountcenter/getsubscribersession.js?method=ajax&session=";
  window.SEATIMESCO.singleSignOn.info.commenterSessionURL     = "https://secure.seattletimes.com/accountcenter/coraltoken.js?token=";
  window.SEATIMESCO.singleSignOn.info.analyticsURL            = "https://secure.seattletimes.com/accountcenter/soa.js?method=ajax&session=";
  </script><link rel='preload' href='https://www.seattletimes.com/wp-content/themes/st_refresh/js/site-wide/dist/st-blocking-bundle.js?ver=1739903192' as='script' fetchpriority='low' /><link rel='preload' href='https://www.seattletimes.com/wp-content/themes/st_refresh/css/styles.min.css?ver=1739903192' as='style' fetchpriority='high' /><link rel='preload' href='https://www.seattletimes.com/wp-content/themes/st_refresh/styles/dist/style.css?ver=1739903192' as='style' fetchpriority='high' /><link rel='preload' href='https://www.seattletimes.com/wp-content/themes/st_refresh/js/bundle.min.js?ver=1739903192' as='script' fetchpriority='low' /><link rel='preload' href='https://www.seattletimes.com/wp-content/themes/st_refresh/js/site-wide/dist/st-sitewide-bundle.js?ver=1739903192' as='script' fetchpriority='low' />        <link rel="preload" href="https://cdn.optimizely.com/js/25075460524.js" as="script" fetchpriority="low">
            <script>
      window.SEATIMESCO = window.SEATIMESCO || {};
      window.SEATIMESCO.experiments = window.SEATIMESCO.experiments || {};
      window.SEATIMESCO.experiments.property = "UA-52488759-1";
      window.SEATIMESCO.experiments.defaultHide = ".river-group.extra-items.elsewhere.five-col.u-dib.full-width-content";
      window.SEATIMESCO.experiments.timeout = 4000;
      window.SEATIMESCO.experiments.adsWait = false;
      window.SEATIMESCO.experiments.messagingWait = false;
      window.SEATIMESCO.experiments.curationWait = false;
      </script>

              <script async src="https://cdn.optimizely.com/js/25075460524.js"></script>
          <script>
      window.SEATIMESCO = window.SEATIMESCO || {};
      window.SEATIMESCO.abTimeout = 3000;
      window.SEATIMESCO.ads = window.SEATIMESCO.ads || {};
      window.SEATIMESCO.ads.disabled = false;
      window.SEATIMESCO.ads.adFreeMatherSegment = 'MATHER_U3_ADFREEGROUPB_20210610';
      window.SEATIMESCO.ads.adFreeShowBrandedContent = 'false';
      window.SEATIMESCO.ads.dfpEnv = 'prod';
      window.SEATIMESCO.ads.adUnitPath = '/81279359/seattletimes.com/404';
      window.SEATIMESCO.ads.isTakeover = false;
      window.SEATIMESCO.ads.htlUrl = 'https://htlbid.com/v3/seattletimes.com/htlbid.js';
      window.htlbid = window.htlbid || {};
      htlbid.cmd = htlbid.cmd || [];
      htlbid.cmd.push(function() {
        htlbid.layout('universal'); // Leave as 'universal' or add custom layout
        htlbid.setTargeting('environment','prod');
        htlbid.setTargeting('is_testing','no'); // Set to "no" for production
        htlbid.setTargeting('type','404_page');
        htlbid.setTargeting('id','');
        htlbid.setTargeting('category','/81279359/seattletimes.com/404');
        htlbid.setTargeting('categories','');
        htlbid.setTargeting('tag','');
        htlbid.setTargeting('author','');
        htlbid.setTargeting('app','web');
        htlbid.setFirstPartyData({
          site: {
            page_type: '404_page',
            keywords: ''
          }
        });
      });

    </script>        <script>
          window.SEATIMESCO = window.SEATIMESCO || {};
          window.SEATIMESCO.browser = window.SEATIMESCO.browser || {};
          window.SEATIMESCO.browser.support = {};
          window.SEATIMESCO.browser.detected = {};
          window.SEATIMESCO.browser.support.edge = 0;
          window.SEATIMESCO.browser.support.safari = 0;
          window.SEATIMESCO.browser.support.firefox = 0;
          window.SEATIMESCO.browser.support.chrome = 0;
          window.SEATIMESCO.browser.support.ie = 12;
        </script><meta name='robots' content='max-image-preview:large' />
<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel='dns-prefetch' href='//use.typekit.net' />
<link rel='dns-prefetch' href='//awsapi.seattletimes.com' />
<link rel='dns-prefetch' href='//static.chartbeat.com' />
<link rel='dns-prefetch' href='//mab.chartbeat.com' />
<link rel='dns-prefetch' href='//seattle-times.zeustechnology.com' />
<link rel='dns-prefetch' href='//securepubads.g.doubleclick.net' />
<link rel='dns-prefetch' href='//static.doubleclick.net' />
<link rel='dns-prefetch' href='//ib.adnxs.com' />
<link rel='dns-prefetch' href='//bidder.criteo.com' />
<link rel='dns-prefetch' href='//static.criteo.net' />
<link rel='dns-prefetch' href='//connect.facebook.net' />
<link rel='dns-prefetch' href='//as-sec.casalemedia.com' />
<link rel='dns-prefetch' href='//js-sec.indexww.com' />
<link rel='dns-prefetch' href='//seattle-times-d.openx.net' />
<link rel='dns-prefetch' href='//hbopenbid.pubmatic.com' />
<link rel='dns-prefetch' href='//fastlane.rubiconproject.com' />
<link rel='dns-prefetch' href='//ap.lijit.com' />
<link rel='dns-prefetch' href='//tlx.3lift.com' />
<link rel='dns-prefetch' href='//c.amazon-adsystem.com' />
<link rel='dns-prefetch' href='//scripts.webcontentassessor.com' />
<link rel='dns-prefetch' href='//widgets-lts.media.weather.com' />
<link rel='preconnect' href='//i.matheranalytics.com' />
<link rel='preconnect' href='//geolocation.onetrust.com' />
<link rel='preconnect' href='//js.matheranalytics.com' />
<link rel='preconnect' href='//google-analytics.com' />
<link rel='preconnect' href='//cdn.cookielaw.org' />
<link rel="alternate" type="application/rss+xml" title="The Seattle Times &raquo; Feed" href="https://www.seattletimes.com/feed/" />
<link rel="alternate" type="application/rss+xml" title="The Seattle Times &raquo; Comments Feed" href="https://www.seattletimes.com/comments/feed/" />

      <script type="text/javascript">
        dataLayer = [{"timestamp":1740125806,"contentType":"404_page","canonicalURL":"","domain":"www.seattletimes.com","errorType":"404"}];
        window.SEATIMESCO = window.SEATIMESCO || {}; window.SEATIMESCO.contentInfo = {"timestamp":1740125806,"contentType":"404_page","canonicalURL":"","domain":"www.seattletimes.com","errorType":"404"};
      </script>
      
        <!-- Google Tag Manager -->
        <script>
          (function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
          new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
          j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
          '//www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
          })(window,document,'script','dataLayer','GTM-KDZ92J');
        </script>
        <script type="text/javascript">
/* <![CDATA[ */
window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/15.0.3\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/15.0.3\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/www.seattletimes.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=6.6.1"}};
/*! This file is auto-generated */
!function(i,n){var o,s,e;function c(e){try{var t={supportTests:e,timestamp:(new Date).valueOf()};sessionStorage.setItem(o,JSON.stringify(t))}catch(e){}}function p(e,t,n){e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(t,0,0);var t=new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data),r=(e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(n,0,0),new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data));return t.every(function(e,t){return e===r[t]})}function u(e,t,n){switch(t){case"flag":return n(e,"\ud83c\udff3\ufe0f\u200d\u26a7\ufe0f","\ud83c\udff3\ufe0f\u200b\u26a7\ufe0f")?!1:!n(e,"\ud83c\uddfa\ud83c\uddf3","\ud83c\uddfa\u200b\ud83c\uddf3")&&!n(e,"\ud83c\udff4\udb40\udc67\udb40\udc62\udb40\udc65\udb40\udc6e\udb40\udc67\udb40\udc7f","\ud83c\udff4\u200b\udb40\udc67\u200b\udb40\udc62\u200b\udb40\udc65\u200b\udb40\udc6e\u200b\udb40\udc67\u200b\udb40\udc7f");case"emoji":return!n(e,"\ud83d\udc26\u200d\u2b1b","\ud83d\udc26\u200b\u2b1b")}return!1}function f(e,t,n){var r="undefined"!=typeof WorkerGlobalScope&&self instanceof WorkerGlobalScope?new OffscreenCanvas(300,150):i.createElement("canvas"),a=r.getContext("2d",{willReadFrequently:!0}),o=(a.textBaseline="top",a.font="600 32px Arial",{});return e.forEach(function(e){o[e]=t(a,e,n)}),o}function t(e){var t=i.createElement("script");t.src=e,t.defer=!0,i.head.appendChild(t)}"undefined"!=typeof Promise&&(o="wpEmojiSettingsSupports",s=["flag","emoji"],n.supports={everything:!0,everythingExceptFlag:!0},e=new Promise(function(e){i.addEventListener("DOMContentLoaded",e,{once:!0})}),new Promise(function(t){var n=function(){try{var e=JSON.parse(sessionStorage.getItem(o));if("object"==typeof e&&"number"==typeof e.timestamp&&(new Date).valueOf()<e.timestamp+604800&&"object"==typeof e.supportTests)return e.supportTests}catch(e){}return null}();if(!n){if("undefined"!=typeof Worker&&"undefined"!=typeof OffscreenCanvas&&"undefined"!=typeof URL&&URL.createObjectURL&&"undefined"!=typeof Blob)try{var e="postMessage("+f.toString()+"("+[JSON.stringify(s),u.toString(),p.toString()].join(",")+"));",r=new Blob([e],{type:"text/javascript"}),a=new Worker(URL.createObjectURL(r),{name:"wpTestEmojiSupports"});return void(a.onmessage=function(e){c(n=e.data),a.terminate(),t(n)})}catch(e){}c(n=f(s,u,p))}t(n)}).then(function(e){for(var t in e)n.supports[t]=e[t],n.supports.everything=n.supports.everything&&n.supports[t],"flag"!==t&&(n.supports.everythingExceptFlag=n.supports.everythingExceptFlag&&n.supports[t]);n.supports.everythingExceptFlag=n.supports.everythingExceptFlag&&!n.supports.flag,n.DOMReady=!1,n.readyCallback=function(){n.DOMReady=!0}}).then(function(){return e}).then(function(){var e;n.supports.everything||(n.readyCallback(),(e=n.source||{}).concatemoji?t(e.concatemoji):e.wpemoji&&e.twemoji&&(t(e.twemoji),t(e.wpemoji)))}))}((window,document),window._wpemojiSettings);
/* ]]> */
</script>
<link rel="preload" href="https://www.seattletimes.com/wp-content/plugins/st-advertising/dist/st-advertising-bundle.js?ver=1739903191" as="script" fetchpriority="low"><link rel="preload" href="https://seattletimes.coral.coralproject.net/assets/js/count.js" as="script" fetchpriority="low"><link rel="preload" href="https://seattletimes.coral.coralproject.net/assets/js/embed.js" as="script" fetchpriority="low"><link rel="preload" href="https://www.seattletimes.com/wp-content/plugins/st-coral-talk/dist/st-coraltalk-bundle.js?ver=1739903191" as="script" fetchpriority="low"><link rel="preload" href="https://www.seattletimes.com/wp-content/plugins/st-coral-talk/dist/main.css?ver=1739903191" as="style" fetchpriority="high"><link rel="preload" href="https://www.seattletimes.com/wp-content/plugins/st-gutenberg/css/jwplayer.css?ver=1739903191" as="style" fetchpriority="high"><link rel="preload" href="https://www.seattletimes.com/wp-content/plugins/st-gutenberg/css/graphics-gallery.css?ver=1739903191" as="style" fetchpriority="high"><link rel='preload' href='https://fonts.googleapis.com/css2?family=Open+Sans:wght@700&display=swap' as='font' fetchpriority='high' ><link rel="preload" href="https://www.seattletimes.com/wp-content/plugins/st-legacy-shortcodes/css/shortcodes-public.css?ver=1739903191" as="style" fetchpriority="high"><link rel="preload" href="https://www.seattletimes.com/wp-content/plugins/st-spruce-app/dist/st-spruce-bundle.js?ver=1739903191" as="script" fetchpriority="low"><link rel="preload" href="https://www.seattletimes.com/wp-content/plugins/st-spruce-deuce/dist/st-spruce-app.js?ver=1739903237" as="script" fetchpriority="low"><link rel='stylesheet' id='st-style-css' href='https://www.seattletimes.com/wp-content/themes/st_refresh/css/styles.min.css?ver=1739903192' type='text/css' media='all' />
<link rel='stylesheet' id='st-new-style-css' href='https://www.seattletimes.com/wp-content/themes/st_refresh/styles/dist/style.css?ver=1739903192' type='text/css' media='all' />
<style id='wp-emoji-styles-inline-css' type='text/css'>

	img.wp-smiley, img.emoji {
		display: inline !important;
		border: none !important;
		box-shadow: none !important;
		height: 1em !important;
		width: 1em !important;
		margin: 0 0.07em !important;
		vertical-align: -0.1em !important;
		background: none !important;
		padding: 0 !important;
	}
</style>
<style id='co-authors-plus-coauthors-style-inline-css' type='text/css'>
.wp-block-co-authors-plus-coauthors.is-layout-flow [class*=wp-block-co-authors-plus]{display:inline}

</style>
<style id='co-authors-plus-avatar-style-inline-css' type='text/css'>
.wp-block-co-authors-plus-avatar :where(img){height:auto;max-width:100%;vertical-align:bottom}.wp-block-co-authors-plus-coauthors.is-layout-flow .wp-block-co-authors-plus-avatar :where(img){vertical-align:middle}.wp-block-co-authors-plus-avatar:is(.alignleft,.alignright){display:table}.wp-block-co-authors-plus-avatar.aligncenter{display:table;margin-inline:auto}

</style>
<style id='co-authors-plus-image-style-inline-css' type='text/css'>
.wp-block-co-authors-plus-image{margin-bottom:0}.wp-block-co-authors-plus-image :where(img){height:auto;max-width:100%;vertical-align:bottom}.wp-block-co-authors-plus-coauthors.is-layout-flow .wp-block-co-authors-plus-image :where(img){vertical-align:middle}.wp-block-co-authors-plus-image:is(.alignfull,.alignwide) :where(img){width:100%}.wp-block-co-authors-plus-image:is(.alignleft,.alignright){display:table}.wp-block-co-authors-plus-image.aligncenter{display:table;margin-inline:auto}

</style>
<style id='global-styles-inline-css' type='text/css'>
:root{--wp--preset--aspect-ratio--square: 1;--wp--preset--aspect-ratio--4-3: 4/3;--wp--preset--aspect-ratio--3-4: 3/4;--wp--preset--aspect-ratio--3-2: 3/2;--wp--preset--aspect-ratio--2-3: 2/3;--wp--preset--aspect-ratio--16-9: 16/9;--wp--preset--aspect-ratio--9-16: 9/16;--wp--preset--color--black: #000000;--wp--preset--color--cyan-bluish-gray: #abb8c3;--wp--preset--color--white: #ffffff;--wp--preset--color--pale-pink: #f78da7;--wp--preset--color--vivid-red: #cf2e2e;--wp--preset--color--luminous-vivid-orange: #ff6900;--wp--preset--color--luminous-vivid-amber: #fcb900;--wp--preset--color--light-green-cyan: #7bdcb5;--wp--preset--color--vivid-green-cyan: #00d084;--wp--preset--color--pale-cyan-blue: #8ed1fc;--wp--preset--color--vivid-cyan-blue: #0693e3;--wp--preset--color--vivid-purple: #9b51e0;--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,rgba(6,147,227,1) 0%,rgb(155,81,224) 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,rgba(252,185,0,1) 0%,rgba(255,105,0,1) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,rgba(255,105,0,1) 0%,rgb(207,46,46) 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);--wp--preset--gradient--blush-light-purple: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);--wp--preset--gradient--luminous-dusk: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);--wp--preset--gradient--pale-ocean: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);--wp--preset--gradient--electric-grass: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);--wp--preset--gradient--midnight: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);--wp--preset--font-size--small: 13px;--wp--preset--font-size--medium: 20px;--wp--preset--font-size--large: 36px;--wp--preset--font-size--x-large: 42px;--wp--preset--spacing--20: 0.44rem;--wp--preset--spacing--30: 0.67rem;--wp--preset--spacing--40: 1rem;--wp--preset--spacing--50: 1.5rem;--wp--preset--spacing--60: 2.25rem;--wp--preset--spacing--70: 3.38rem;--wp--preset--spacing--80: 5.06rem;--wp--preset--shadow--natural: 6px 6px 9px rgba(0, 0, 0, 0.2);--wp--preset--shadow--deep: 12px 12px 50px rgba(0, 0, 0, 0.4);--wp--preset--shadow--sharp: 6px 6px 0px rgba(0, 0, 0, 0.2);--wp--preset--shadow--outlined: 6px 6px 0px -3px rgba(255, 255, 255, 1), 6px 6px rgba(0, 0, 0, 1);--wp--preset--shadow--crisp: 6px 6px 0px rgba(0, 0, 0, 1);}:where(.is-layout-flex){gap: 0.5em;}:where(.is-layout-grid){gap: 0.5em;}body .is-layout-flex{display: flex;}.is-layout-flex{flex-wrap: wrap;align-items: center;}.is-layout-flex > :is(*, div){margin: 0;}body .is-layout-grid{display: grid;}.is-layout-grid > :is(*, div){margin: 0;}:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}.has-black-color{color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-color{color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-color{color: var(--wp--preset--color--white) !important;}.has-pale-pink-color{color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-color{color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-color{color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-color{color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-color{color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-color{color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-color{color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-color{color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-color{color: var(--wp--preset--color--vivid-purple) !important;}.has-black-background-color{background-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-background-color{background-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-background-color{background-color: var(--wp--preset--color--white) !important;}.has-pale-pink-background-color{background-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-background-color{background-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-background-color{background-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-background-color{background-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-background-color{background-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-background-color{background-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-background-color{background-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-background-color{background-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-background-color{background-color: var(--wp--preset--color--vivid-purple) !important;}.has-black-border-color{border-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-border-color{border-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-border-color{border-color: var(--wp--preset--color--white) !important;}.has-pale-pink-border-color{border-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-border-color{border-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-border-color{border-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-border-color{border-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-border-color{border-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-border-color{border-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-border-color{border-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-border-color{border-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-border-color{border-color: var(--wp--preset--color--vivid-purple) !important;}.has-vivid-cyan-blue-to-vivid-purple-gradient-background{background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;}.has-light-green-cyan-to-vivid-green-cyan-gradient-background{background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;}.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;}.has-luminous-vivid-orange-to-vivid-red-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;}.has-very-light-gray-to-cyan-bluish-gray-gradient-background{background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;}.has-cool-to-warm-spectrum-gradient-background{background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;}.has-blush-light-purple-gradient-background{background: var(--wp--preset--gradient--blush-light-purple) !important;}.has-blush-bordeaux-gradient-background{background: var(--wp--preset--gradient--blush-bordeaux) !important;}.has-luminous-dusk-gradient-background{background: var(--wp--preset--gradient--luminous-dusk) !important;}.has-pale-ocean-gradient-background{background: var(--wp--preset--gradient--pale-ocean) !important;}.has-electric-grass-gradient-background{background: var(--wp--preset--gradient--electric-grass) !important;}.has-midnight-gradient-background{background: var(--wp--preset--gradient--midnight) !important;}.has-small-font-size{font-size: var(--wp--preset--font-size--small) !important;}.has-medium-font-size{font-size: var(--wp--preset--font-size--medium) !important;}.has-large-font-size{font-size: var(--wp--preset--font-size--large) !important;}.has-x-large-font-size{font-size: var(--wp--preset--font-size--x-large) !important;}
:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}
:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}
:root :where(.wp-block-pullquote){font-size: 1.5em;line-height: 1.6;}
</style>
<link rel='stylesheet' id='open-sans-css' href='https://fonts.googleapis.com/css?family=Open+Sans%3A300italic%2C400italic%2C600italic%2C300%2C400%2C600&#038;subset=latin%2Clatin-ext&#038;display=fallback&#038;ver=6.6.1' type='text/css' media='all' />
<link rel='stylesheet' id='st-shortcode-public-styles-css' href='https://www.seattletimes.com/wp-content/plugins/st-legacy-shortcodes/css/shortcodes-public.css?ver=1739903191' type='text/css' media='all' />
<script type='text/javascript' id='st-blocking-script' src='https://www.seattletimes.com/wp-content/themes/st_refresh/js/site-wide/dist/st-blocking-bundle.js?ver=1739903192' defer></script><link rel="https://api.w.org/" href="https://www.seattletimes.com/wp-json/" />
  <meta property="fb:admins" content="2737159" />

  <!-- Add EchoBox Script -->
  <script async id="ebx" src="//applets.ebxcdn.com/ebx.js"></script>


    </head>

  
<body class="error404 two-column">
  <!-- ST SVG Icons --><svg xmlns="http://www.w3.org/2000/svg" display="none">
    <symbol id="icon-hamburger-menu">
        <path d="M25 2c0 1.104-.896 2-2 2H2C.896 4 0 3.104 0 2s.896-2 2-2h21c1.104 0 2 .896 2 2zM25 10c0 1.104-.896 2-2 2H2c-1.104 0-2-.896-2-2s.896-2 2-2h21c1.104 0 2 .896 2 2zM25 18c0 1.105-.896 2-2 2H2c-1.104 0-2-.896-2-2s.896-2 2-2h21c1.104 0 2 .896 2 2z"/>
    </symbol>
    <symbol id="icon-x" viewBox="0 0 512 512">
        <path d="M508.6,405.3c2.3,3.2,3.4,6.1,3.4,8.8c0,2.7-1.1,5.6-3.4,8.8l-85.8,85.8c-3.2,2.3-6.1,3.4-8.8,3.4c-2.7,0-5.6-1.1-8.8-3.4L256,359.3L106.7,508.6c-3.2,2.3-6.1,3.4-8.8,3.4c-2.7,0-5.6-1.1-8.8-3.4L3.4,422.8c-2.3-3.2-3.4-6.1-3.4-8.8c0-2.7,1.1-5.6,3.4-8.8L152.7,256L3.4,106.7c-2.3-3.2-3.4-6.1-3.4-8.8c0-2.7,1.1-5.6,3.4-8.8L89.2,3.4C92.3,1.1,95.3,0,97.9,0c2.7,0,5.6,1.1,8.8,3.4L256,152.7L405.3,3.4c3.2-2.3,6.1-3.4,8.8-3.4c2.7,0,5.6,1.1,8.8,3.4l85.8,85.8c2.3,3.2,3.4,6.1,3.4,8.8s-1.1,5.6-3.4,8.8L359.3,256L508.6,405.3z"/>
    </symbol>
    <symbol id="icon-search" viewBox="0 0 512 512">
        <path d="M320,0c52.9,0,98.2,18.8,135.7,56.3C493.2,93.9,512,139.1,512,192c0,52.9-18.8,98.2-56.3,135.7S372.9,384,320,384c-37.5,0-71.7-9.9-102.5-29.6L72.9,499.5c-8.3,8.3-18.4,12.5-30.2,12.5s-21.9-4.2-30.2-12.5C4.2,491.2,0,481.2,0,469.3c0-11.9,4.2-21.9,12.5-30.2l145.2-144.6c-19.8-30.8-29.6-65-29.6-102.5c0-52.9,18.8-98.2,56.3-135.7S267.1,0,320,0L320,0z M320,320c35.2,0,65.3-12.5,90.4-37.6c25.1-25.1,37.6-55.2,37.6-90.4c0-35.2-12.6-65.3-37.6-90.4C385.3,76.6,355.2,64,320,64c-35.2,0-65.3,12.5-90.4,37.6S192,156.8,192,192s12.5,65.3,37.6,90.4S284.9,320,320,320z"/>
    </symbol>
    <symbol id="icon-chevron" viewBox="0 0 512 512">
        <path d="M512,170.8c0,2.4-1,4.9-3,7.7L264.1,423.4c-5.1,5.1-10.2,5.1-15.4,0L3.8,178.5c-5.1-5.1-5.1-10.2,0-15.4l74.5-74.5c5.1-5.1,10.2-5.1,15.4,0l162.7,163.3L419.1,88.6c5.1-5.1,10.2-5.1,15.4,0l74.5,74.5C511,165.9,512,168.5,512,170.8L512,170.8z"/>
    </symbol>
    <symbol id="icon-lock" viewBox="0 0 512 512">
        <path id="lock" class="st0" d="M416,223c8.7,0,16.2,3.2,22.5,9.5c6.3,6.3,9.5,13.8,9.5,22.5v224c0,8.7-3.2,16.2-9.5,22.5
        c-6.3,6.3-13.8,9.5-22.5,9.5H96c-8.7,0-16.2-3.2-22.5-9.5c-6.3-6.3-9.5-13.8-9.5-22.5V255c0-8.7,3.2-16.2,9.5-22.5
	    c6.3-6.3,13.8-9.5,22.5-9.5h32v-96c0-35.2,12.5-65.3,37.6-90.4S220.8-1,256-1c35.2,0,65.3,12.6,90.4,37.6S384,91.8,384,127v96
	    L416,223L416,223z M192,127v96h128v-96c0-17.8-6.2-32.9-18.7-45.3C288.9,69.2,273.8,63,256,63c-17.8,0-32.9,6.2-45.3,18.7
	    C198.2,94.1,192,109.2,192,127z"/>
    </symbol>
    <symbol id="icon-st-logo-round" viewbox="0 0 17.55 17.55">
        <defs>
            <style>
            .cls-1, .cls-2 { fill: #fff; }
            .cls-2 { fill-rule: evenodd; }
            </style>
        </defs>
        <circle cx="8.77" cy="8.77" r="8.77"></circle>
        <g>
            <path class="cls-2" d="m7.22,6.72c-.45-.63-1.36-1.51-2.23-1.51-.58,0-.85.36-.85.65,0,.4.34.66,1.2,1.22,1.71,1.1,3.04,1.86,3.04,3.32s-1.64,2.07-2.12,3.21h-.03c-1.07-1.55-2.93-1.86-3.69-1.17l-.06-.04c.1-.7.52-1.94,1.53-1.94.93,0,2.15,1.23,2.91,1.55.11.04.21.02.28-.07.09-.12.16-.31.16-.6,0-2.06-4.26-2.64-4.26-4.29,0-.39.36-1.08.85-1.7.65-.8,1.31-1.16,2.03-1.16,1.11,0,1.66.83,2.13.83.2,0,.32-.08.44-.24l.12.1c-.27.29-.59.62-.86.98l-.04.03c-.46.17-.4.62-.54.82"></path>
            <path class="cls-2" d="m7.08,11.38c0-1.83-4.31-2.4-4.31-4.32h-.05c-.31,2.16,3.93,2.71,4.31,4.33h.05Z"></path>
            <path class="cls-2" d="m7.33,6.81c-.01-.25.06-.51.25-.71.22-.23.53-.33,1.05-.33.96,0,2.65.72,4.13.72,1.29,0,2.17-1.26,2.5-1.92l-.14-.4h-.02c-.08.56-.56,1.24-1.61,1.24s-2.98-.77-4.01-.77c-1.49,0-2.2,1.07-2.33,1.96l.17.24.03-.02Z"></path>
            <rect class="cls-1" x="12.17" y="6.24" width=".32" height="6.44"></rect>
            <path class="cls-2" d="m9.86,6.3l.16.1c-.69.51-1.23,1.46-1.23,2.65,0,1.98,1.15,3.61,3,3.61,1.07,0,1.74-.55,2.07-1.08h.02s.03.48.03.48c-.52.47-1.63,1.29-3.04,1.29-2.17,0-3.49-1.49-3.49-3.46,0-1.83,1.27-2.97,2.47-3.59"></path>
            <path class="cls-2" d="m11.62,6.23l-.82.45c-.51.28-.62.57-.62,1.14,0,.51.14,1.36.14,2.05s-.14.92-.74,1.17l.1.19c.39-.18,1.07-.52,1.51-.8.36-.23.42-.36.42-.72v-2.22c0-.72.02-.94.15-1.13l-.15-.13Z"></path>
        </g>
    </symbol>    
</svg>

  
    <!-- OneTrust Cookies Consent Notice start -->
    <script async src="https://cdn.cookielaw.org/scripttemplates/otSDKStub.js" type="text/javascript" charset="UTF-8" data-domain-script="4bed09d4-1fd8-4251-bf32-d5e876bff7d5"></script>

    <script type="text/javascript">
    function OptanonWrapper() { }
    </script>

    <script>
    (function() {
    var OTTag = document.createElement('script');
    // Add standard script attributes
    OTTag.setAttribute('src', 'https://cdn.cookielaw.org/opt-out/otCCPAiab.js');
    OTTag.setAttribute('type', 'text/javascript');
    OTTag.setAttribute('charset', 'UTF-8');
    OTTag.setAttribute('async', true);

     // Add custom attributes
    OTTag.setAttribute('ccpa-opt-out-ids', 'SM,T,P');
    OTTag.setAttribute('ccpa-opt-out-geo', 'all');
    OTTag.setAttribute('ccpa-opt-out-lspa', 'false');

     document.body.appendChild(OTTag);
    })();
    </script>
    <!-- OneTrust Cookies Consent Notice end -->
    
        <!-- Google Tag Manager (noscript) -->
        <noscript>
          <iframe src="https://www.googletagmanager.com/ns.html?id=GTM-KDZ92J" height="0" width="0" style="display:none;visibility:hidden"></iframe>
        </noscript>
            <div id="ad-wallpaper" class="hide">
      <div id='htlad_wallpaper' class='htlad htlad-wallpaper '  data-unit='/81279359/seattletimes.com/404'></div>    </div>
    <a class="skip-link screen-reader-text" href="#content">Skip to content</a>
<div id="container" class="site container">
  <div class="ad ad-top-one u-bg-dark-off-white" id="ad-flex-top">
    <div class="top-ad-wrapper">
      <div class='top-wide'>
        <div id='htlad_top' class='htlad htlad-top ad'  data-unit='/81279359/seattletimes.com/404'></div>      </div>
    </div>
  </div>
  <header class="global-header standard">

    <div class="global-header-top">

      <div class="wrapper">

        <div class="main-nav">

          <div class="main-nav-header">

            <button id="hamburger-button" aria-label="Open" class="menu-button"
              aria-controls="menu-hamburger-accordion-menu" aria-expanded="false">
              <svg class="hamburger-svg icon">
                <use xlink:href="#icon-hamburger-menu"></use>
              </svg>
            </button>

            <div class="u-di" itemprop="publisher" itemscope itemtype="http://schema.org/Organization">
              <div class="u-di" itemprop="logo" itemscope itemtype="https://schema.org/ImageObject">
                <a href="https://www.seattletimes.com" class="header-wordmark" title="The Seattle Times"></a>
                <meta itemprop="url" content="https://www.seattletimes.com/wp-content/themes/st_refresh/img/st-meta-facebook.png">
              </div>
              <meta itemprop="name" content="The Seattle Times">
            </div>

          </div>

          <nav class="popup main-nav-body">

            <div class="main-nav-header highlighted">

              <button id="hamburger-close-button" aria-label="Close" class="menu-button"
                aria-controls="menu-hamburger-accordion-menu" aria-expanded="false">
                <svg class="icon-x icon-white icon icon-small">
                  <use xlink:href="#icon-x"></use>
                </svg>
              </button>

              <a href="https://www.seattletimes.com" class="header-wordmark white" title="The Seattle Times"></a>

            </div>

            <div id="main-nav-container" class="main-nav-container">

  <ul id="menu-hamburger-accordion-menu" class="nav-accordion"><li id="menu-item-9817233" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-has-children menu-item-9817233"><a href="/seattle-news/">Local News</a>
        <button class='sub-menu-toggle u-border-n u-bg-transparent'>
          <svg class='icon-chevron icon'>
            <use xlink:href='#icon-chevron'></use>
          </svg>
        </button>
      
<ul class="sub-menu">
	<li id="menu-item-9817255" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-9817255"><a href="/seattle-news/transportation/">Traffic Lab</a></li>
	<li id="menu-item-9818656" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-9818656"><a href="/seattle-news/law-justice/">Law &amp; Justice</a></li>
	<li id="menu-item-9817246" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-9817246"><a href="/seattle-news/politics/">Local Politics</a></li>
	<li id="menu-item-9818658" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-9818658"><a href="/seattle-news/education/">Education</a></li>
	<li id="menu-item-10273892" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-10273892"><a href="/education-lab/">Education Lab</a></li>
	<li id="menu-item-9818657" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-9818657"><a href="/seattle-news/eastside/">Eastside</a></li>
	<li id="menu-item-17057196" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-17057196"><a href="https://www.seattletimes.com/seattle-news/climate-lab/">Climate Lab</a></li>
	<li id="menu-item-14570171" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-14570171"><a href="/seattle-news/environment/">Environment</a></li>
	<li id="menu-item-9818659" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-9818659"><a href="/seattle-news/health/">Health</a></li>
	<li id="menu-item-9876206" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-9876206"><a href="/seattle-news/data/">Data</a></li>
	<li id="menu-item-16189910" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-16189910"><a href="/seattle-news/mental-health/">Mental Health</a></li>
	<li id="menu-item-10552763" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-10552763"><a href="/seattle-news/homeless/">Project Homeless</a></li>
	<li id="menu-item-9876219" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-9876219"><a href="/seattle-news/times-watchdog/">Times Watchdog</a></li>
</ul>
</li>
<li id="menu-item-9817234" class="menu-item menu-item-type-taxonomy menu-item-object-section current-post-ancestor current-menu-parent current-post-parent menu-item-has-children menu-item-9817234"><a href="/business/">Business &#038; Tech</a>
        <button class='sub-menu-toggle u-border-n u-bg-transparent'>
          <svg class='icon-chevron icon'>
            <use xlink:href='#icon-chevron'></use>
          </svg>
        </button>
      
<ul class="sub-menu">
	<li id="menu-item-9818664" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-9818664"><a href="/business/boeing-aerospace/">Boeing &amp; Aerospace</a></li>
	<li id="menu-item-9876204" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-9876204"><a href="/business/amazon/">Amazon</a></li>
	<li id="menu-item-9818666" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-9818666"><a href="/business/microsoft/">Microsoft</a></li>
	<li id="menu-item-9818662" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-9818662"><a href="/business/technology/">Technology</a></li>
	<li id="menu-item-10896521" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-10896521"><a href="/business/real-estate/">Real Estate</a></li>
	<li id="menu-item-9818665" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-9818665"><a href="/business/economy/">Economy</a></li>
	<li id="menu-item-16189891" class="menu-item menu-item-type-taxonomy menu-item-object-post_tag menu-item-16189891"><a href="https://www.seattletimes.com/tag/artificial-intelligence/">Artificial Intelligence</a></li>
</ul>
</li>
<li id="menu-item-9817235" class="menu-item menu-item-type-taxonomy menu-item-object-section current-post-ancestor menu-item-has-children menu-item-9817235"><a href="/nation-world/">Nation &amp; World</a>
        <button class='sub-menu-toggle u-border-n u-bg-transparent'>
          <svg class='icon-chevron icon'>
            <use xlink:href='#icon-chevron'></use>
          </svg>
        </button>
      
<ul class="sub-menu">
	<li id="menu-item-9876207" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-9876207"><a href="/nation-world/nation-politics/">Nation &amp; World Politics</a></li>
	<li id="menu-item-9876208" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-9876208"><a href="/nation-world/oddities/">Oddities</a></li>
</ul>
</li>
<li id="menu-item-9817237" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-has-children menu-item-9817237"><a href="/sports/">Sports</a>
        <button class='sub-menu-toggle u-border-n u-bg-transparent'>
          <svg class='icon-chevron icon'>
            <use xlink:href='#icon-chevron'></use>
          </svg>
        </button>
      
<ul class="sub-menu">
	<li id="menu-item-9817253" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-9817253"><a href="/sports/seahawks/">Seahawks</a></li>
	<li id="menu-item-9817252" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-9817252"><a href="/sports/mariners/">Mariners</a></li>
	<li id="menu-item-9817251" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-9817251"><a href="/sports/uw-huskies/">Huskies</a></li>
	<li id="menu-item-9817250" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-9817250"><a href="/sports/wsu-cougars/">Cougars</a></li>
	<li id="menu-item-9817279" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-9817279"><a href="/sports/storm/">Storm</a></li>
	<li id="menu-item-16189892" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-16189892"><a href="/sports/kraken/">Kraken</a></li>
	<li id="menu-item-9817254" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-9817254"><a href="/sports/sounders/">Sounders</a></li>
	<li id="menu-item-16189895" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-16189895"><a href="/sports/reign/">Reign</a></li>
	<li id="menu-item-9817280" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-9817280"><a href="/sports/high-school/">High School Sports</a></li>
	<li id="menu-item-9921459" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-9921459"><a href="/sports/sports-on-tv-radio-2/">On TV/Radio</a></li>
</ul>
</li>
<li id="menu-item-9817238" class="menu-item menu-item-type-taxonomy menu-item-object-section current-post-ancestor current-menu-parent current-post-parent menu-item-has-children menu-item-9817238"><a href="/entertainment/">Entertainment</a>
        <button class='sub-menu-toggle u-border-n u-bg-transparent'>
          <svg class='icon-chevron icon'>
            <use xlink:href='#icon-chevron'></use>
          </svg>
        </button>
      
<ul class="sub-menu">
	<li id="menu-item-9818621" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-9818621"><a href="/entertainment/movies/">Movies</a></li>
	<li id="menu-item-9818619" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-9818619"><a href="/entertainment/books/">Books</a></li>
	<li id="menu-item-9818616" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-9818616"><a href="/entertainment/music/">Music</a></li>
	<li id="menu-item-9818617" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-9818617"><a href="/entertainment/theater/">Theater</a></li>
	<li id="menu-item-9818620" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-9818620"><a href="/entertainment/classical-music/">Classical Music</a></li>
	<li id="menu-item-9876209" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-9876209"><a href="/entertainment/tv/">TV/Streaming</a></li>
	<li id="menu-item-10270568" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-10270568"><a href="/entertainment/comics/">Comics</a></li>
	<li id="menu-item-10270569" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-10270569"><a href="/entertainment/games/">Games &amp; Puzzles</a></li>
	<li id="menu-item-10364413" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-10364413"><a href="https://www.seattletimes.com/horoscopes/">Horoscopes</a></li>
</ul>
</li>
<li id="menu-item-9817239" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-has-children menu-item-9817239"><a href="/life/">Life</a>
        <button class='sub-menu-toggle u-border-n u-bg-transparent'>
          <svg class='icon-chevron icon'>
            <use xlink:href='#icon-chevron'></use>
          </svg>
        </button>
      
<ul class="sub-menu">
	<li id="menu-item-9818643" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-9818643"><a href="/life/food-drink/">Food &amp; Drink</a></li>
	<li id="menu-item-9818653" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-9818653"><a href="/life/travel/">Travel &#038; Outdoors</a></li>
	<li id="menu-item-9818654" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-9818654"><a href="/life/wellness/">Wellness</a></li>
	<li id="menu-item-9876210" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-9876210"><a href="/life/pets/">Pets</a></li>
	<li id="menu-item-9818655" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-9818655"><a href="https://www.seattletimes.com/category/rant-and-rave/">Rant &amp; Rave</a></li>
</ul>
</li>
<li id="menu-item-9818651" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-9818651"><a href="/pacific-nw-magazine/">Pacific NW Magazine</a></li>
<li id="menu-item-9817269" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-9817269"><a href="/homes-real-estate">Homes &#038; Real Estate</a></li>
<li id="menu-item-9817240" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-has-children menu-item-9817240"><a href="/opinion/">Opinion</a>
        <button class='sub-menu-toggle u-border-n u-bg-transparent'>
          <svg class='icon-chevron icon'>
            <use xlink:href='#icon-chevron'></use>
          </svg>
        </button>
      
<ul class="sub-menu">
	<li id="menu-item-9817247" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-9817247"><a href="/opinion/editorials/">Editorials</a></li>
	<li id="menu-item-9817248" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-9817248"><a href="/opinion/letters-to-the-editor/">Letters to the Editor</a></li>
	<li id="menu-item-11126979" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-11126979"><a href="/author/david-horsey/">David Horsey</a></li>
	<li id="menu-item-16189904" class="menu-item menu-item-type-taxonomy menu-item-object-post_tag menu-item-16189904"><a href="https://www.seattletimes.com/tag/free-press/">Free Press</a></li>
</ul>
</li>
<li id="menu-item-10051574" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-10051574"><a title="Video" href="/video/">Video</a></li>
<li id="menu-item-16189911" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-16189911"><a href="/photo-video/">Photography</a></li>
<li id="menu-item-9817274" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-9817274"><a href="https://obituaries.seattletimes.com/">Obituaries</a>
        <button class='sub-menu-toggle u-border-n u-bg-transparent'>
          <svg class='icon-chevron icon'>
            <use xlink:href='#icon-chevron'></use>
          </svg>
        </button>
      
<ul class="sub-menu">
	<li id="menu-item-10203898" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-10203898"><a href="/obituaries/">News Obituaries</a></li>
	<li id="menu-item-10203899" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-10203899"><a href="https://obituaries.seattletimes.com/">Paid Obituaries</a></li>
</ul>
</li>
<li id="menu-item-17518593" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-17518593"><a href="https://www.seattletimes.com/latest/">Latest</a></li>
<li id="menu-item-11044943" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-11044943"><a href="/newsletters/">Newsletters</a></li>
<li id="menu-item-10785263" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-10785263"><a href="https://replica.seattletimes.com/">Print Replica</a></li>
<li id="menu-item-13602289" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-13602289"><a href="https://www.seattletimes.com/todays-times/">Today&#8217;s Paper</a></li>
<li id="menu-item-16189905" class="menu-item menu-item-type-taxonomy menu-item-object-post_tag menu-item-16189905"><a href="https://www.seattletimes.com/tag/inside-the-times/">Inside The Times</a></li>
<li id="menu-item-15320551" class="text-gray menu-item menu-item-type-custom menu-item-object-custom menu-item-15320551"><a href="https://theticket.seattletimes.com">The Ticket</a></li>
<li id="menu-item-16189900" class="text-gray menu-item menu-item-type-taxonomy menu-item-object-section menu-item-16189900"><a href="/explore/">Explore</a></li>
<li id="menu-item-9817256" class="text-gray menu-item menu-item-type-custom menu-item-object-custom menu-item-9817256"><a href="http://jobs.seattletimes.com/">Jobs</a></li>
<li id="menu-item-9817271" class="text-gray menu-item menu-item-type-custom menu-item-object-custom menu-item-9817271"><a href="https://www.bestinthepnw.com/">Best in the PNW</a></li>
</ul>
  <div class="main-nav-separator"></div>
  <ul class="hamburger-login-nav main-nav-list"></ul>
</div>

          </nav>

        </div>

        <nav class='header-utils'>
  <ul>
    <li class='user-link'><a href='/newsletters'>Newsletters</a></li>
    <li class='user-link'><a href='https://secure.seattletimes.com/accountcenter/' class='login st-return'>Log In</a></li>
    <li class='user-link'><a id='header-subscribe-link' href='/subscribe/signup-offers?subsource=voluntary' class='subscribe st-return'>Subscribe</a></li>
  </ul>
</nav>
        <button class="header-search-icon global-search-button">
          <svg class="icon-search icon" aria-label="Search" focusable="false">
            <use xlink:href="#icon-search"></use>
          </svg>
        </button>

      </div>

      <div class="secondary-nav">
        <h1 class="section-title">404 Error</h1>
      </div>

    </div>

    <nav class="section-nav">

      <div class="wrapper">
        <ul id="menu-home-navbar" class="primary-navigation"><li id="menu-item-41596" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-41596"><a title="Seattle News" href="/seattle-news/">Local</a></li>
<li id="menu-item-41597" class="menu-item menu-item-type-taxonomy menu-item-object-section current-post-ancestor current-menu-parent current-post-parent menu-item-41597"><a title="Seattle Business" href="/business/">Biz</a></li>
<li id="menu-item-15840526" class="menu-item menu-item-type-taxonomy menu-item-object-section current-post-ancestor menu-item-15840526"><a href="/nation-world/">Nation</a></li>
<li id="menu-item-41598" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-41598"><a title="Seattle Sports" href="/sports/">Sports</a></li>
<li id="menu-item-41600" class="menu-item menu-item-type-taxonomy menu-item-object-section current-post-ancestor current-menu-parent current-post-parent menu-item-41600"><a title="Seattle Entertainment" href="/entertainment/">Entertainment</a></li>
<li id="menu-item-41601" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-41601"><a title="Seattle Life" href="/life/">Life</a></li>
<li id="menu-item-9717308" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-9717308"><a href="/homes-real-estate/">Homes</a></li>
<li id="menu-item-42489" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-42489"><a title="Seattle Opinion" href="/opinion/">Opinion</a></li>
<li id="menu-item-9805207" class="menu-item menu-item-type-separator menu-item-object-custom menu-item-9805207"><span>|</span></li>
<li id="menu-item-15320564" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-15320564"><a href="https://theticket.seattletimes.com">The Ticket</a></li>
<li id="menu-item-42648" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-42648"><a href="http://jobs.seattletimes.com">Jobs</a></li>
<li id="menu-item-42651" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-42651"><a href="/explore/">Explore</a></li>
<li><button class="nav-all-sections-toggle" aria-label="Toggle mega menu" aria-controls="navAllSections" aria-expanded="false"><svg class="icon-chevron icon"><use xlink:href="#icon-chevron"></use></svg><span class="btn-txt">All Sections</span></button></li></ul><div class="nav-all-sections"><div class="nav-all-sections-wrapper" id="navAllSections"><ul id="menu-all-sections-tier-1" class="all-sections-primary"><li id="menu-item-16189387" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-has-children menu-item-16189387"><a href="/seattle-news/">Local</a>
<ul class="sub-menu">
	<li id="menu-item-16189367" class="menu-item menu-item-type-taxonomy menu-item-object-post_tag menu-item-16189367"><a href="https://www.seattletimes.com/tag/coronavirus/">Coronavirus</a></li>
	<li id="menu-item-9845534" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-9845534"><a href="/seattle-news/transportation/">Traffic Lab</a></li>
	<li id="menu-item-10554575" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-10554575"><a href="/seattle-news/homeless/">Project Homeless</a></li>
	<li id="menu-item-9845529" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-9845529"><a href="/seattle-news/law-justice/">Law &amp; Justice</a></li>
	<li id="menu-item-9845533" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-9845533"><a href="/seattle-news/politics/">Local Politics</a></li>
	<li id="menu-item-9845531" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-9845531"><a href="/seattle-news/education/">Education</a></li>
	<li id="menu-item-10273896" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-10273896"><a href="/education-lab/">Education Lab</a></li>
	<li id="menu-item-9845530" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-9845530"><a href="/seattle-news/eastside/">Eastside</a></li>
	<li id="menu-item-14570160" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-14570160"><a href="/seattle-news/environment/">Environment</a></li>
	<li id="menu-item-9875159" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-9875159"><a href="/seattle-news/northwest/">Northwest</a></li>
	<li id="menu-item-9874852" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-9874852"><a href="/seattle-news/data/">Data</a></li>
	<li id="menu-item-9845532" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-9845532"><a href="/seattle-news/health/">Health</a></li>
	<li id="menu-item-9874851" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-9874851"><a href="/seattle-news/times-watchdog/">Times Watchdog</a></li>
	<li id="menu-item-16189396" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-16189396"><a href="/seattle-news/mental-health/">Mental Health</a></li>
	<li id="menu-item-16189370" class="menu-item menu-item-type-taxonomy menu-item-object-post_tag menu-item-16189370"><a href="https://www.seattletimes.com/tag/inside-the-times/">Inside The Times</a></li>
	<li id="menu-item-9845537" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-9845537"><a href="/obituaries/">News Obituaries</a></li>
	<li id="menu-item-9845491" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-9845491"><a href="/photo-video/">Photo &amp; Video</a></li>
	<li id="menu-item-9845487" class="top-level menu-item menu-item-type-taxonomy menu-item-object-section current-post-ancestor menu-item-9845487"><a href="/nation-world/">Nation &amp; World</a></li>
	<li id="menu-item-9845488" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-9845488"><a href="/nation-world/nation-politics/">Politics</a></li>
	<li id="menu-item-9845538" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-9845538"><a href="/nation-world/oddities/">Oddities</a></li>
</ul>
</li>
<li id="menu-item-9845475" class="menu-item menu-item-type-taxonomy menu-item-object-section current-post-ancestor current-menu-parent current-post-parent menu-item-has-children menu-item-9845475"><a href="/business/">Business</a>
<ul class="sub-menu">
	<li id="menu-item-9845525" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-9845525"><a href="/business/boeing-aerospace/">Boeing</a></li>
	<li id="menu-item-9845524" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-9845524"><a href="/business/amazon/">Amazon</a></li>
	<li id="menu-item-16189365" class="menu-item menu-item-type-taxonomy menu-item-object-post_tag menu-item-16189365"><a href="https://www.seattletimes.com/tag/artificial-intelligence/">Artificial Intelligence</a></li>
	<li id="menu-item-9845526" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-9845526"><a href="/business/microsoft/">Microsoft</a></li>
	<li id="menu-item-9845499" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-9845499"><a href="/business/technology/">Technology</a></li>
	<li id="menu-item-9845539" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-9845539"><a href="/business/economy/">Economy</a></li>
	<li id="menu-item-9845498" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-9845498"><a href="/business/real-estate/">Real Estate</a></li>
</ul>
</li>
<li id="menu-item-9845492" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-has-children menu-item-9845492"><a href="/sports/">Sports</a>
<ul class="sub-menu">
	<li id="menu-item-9845553" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-9845553"><a href="/sports/seahawks/">Seahawks</a></li>
	<li id="menu-item-9845547" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-9845547"><a href="/sports/mariners/">Mariners</a></li>
	<li id="menu-item-9845550" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-9845550"><a href="/sports/uw-huskies/">Huskies</a></li>
	<li id="menu-item-9845548" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-9845548"><a href="/sports/wsu-cougars/">Cougars</a></li>
	<li id="menu-item-16189384" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-16189384"><a href="/sports/storm/">Storm</a></li>
	<li id="menu-item-16189385" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-16189385"><a href="/sports/kraken/">Kraken</a></li>
	<li id="menu-item-9845493" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-9845493"><a href="/sports/sounders/">Sounders</a></li>
	<li id="menu-item-16189382" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-16189382"><a href="/sports/reign/">Reign</a></li>
	<li id="menu-item-9845549" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-9845549"><a href="/sports/high-school/">High Schools</a></li>
	<li id="menu-item-9848994" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-9848994"><a href="/author/matt-calkins">Matt Calkins</a></li>
	<li id="menu-item-9848995" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-9848995"><a href="/author/mike-vorel">Mike Vorel</a></li>
	<li id="menu-item-9848954" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-9848954"><a href="/sports/sports-on-tv-radio-2/">On TV/Radio</a></li>
</ul>
</li>
<li id="menu-item-9845476" class="menu-item menu-item-type-taxonomy menu-item-object-section current-post-ancestor current-menu-parent current-post-parent menu-item-has-children menu-item-9845476"><a href="/entertainment/">Entertainment</a>
<ul class="sub-menu">
	<li id="menu-item-9848965" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-9848965"><a href="/entertainment/movies/">Movies</a></li>
	<li id="menu-item-9848968" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-9848968"><a href="/entertainment/books/">Books</a></li>
	<li id="menu-item-9848966" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-9848966"><a href="/entertainment/music/">Music</a></li>
	<li id="menu-item-9848979" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-9848979"><a href="/entertainment/theater/">Theater</a></li>
	<li id="menu-item-9849076" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-9849076"><a href="/entertainment/classical-music/">Classical Music</a></li>
	<li id="menu-item-9875161" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-9875161"><a href="/entertainment/tv/">TV/Streaming</a></li>
	<li id="menu-item-10270563" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-10270563"><a href="/entertainment/comics/">Comics</a></li>
	<li id="menu-item-10270565" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-10270565"><a href="/entertainment/games/">Games &amp; Puzzles</a></li>
	<li id="menu-item-10364416" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-10364416"><a href="https://www.seattletimes.com/horoscopes/">Horoscopes</a></li>
</ul>
</li>
<li id="menu-item-9845478" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-has-children menu-item-9845478"><a href="/life/">Life</a>
<ul class="sub-menu">
	<li id="menu-item-9845490" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-9845490"><a href="/pacific-nw-magazine/">Pacific NW Magazine</a></li>
	<li id="menu-item-9848964" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-9848964"><a href="/life/food-drink/">Food &amp; Drink</a></li>
	<li id="menu-item-9848980" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-9848980"><a href="/life/wellness/">Wellness</a></li>
	<li id="menu-item-9849021" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-9849021"><a href="/life/home-decor/">Home &amp; Decor</a></li>
	<li id="menu-item-9875160" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-9875160"><a href="/life/pets/">Pets</a></li>
	<li id="menu-item-9848981" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-9848981"><a href="https://www.seattletimes.com/category/rant-and-rave/">Rant &amp; Rave</a></li>
	<li id="menu-item-9849075" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-9849075"><a href="/author/bethany-jean-clement">Bethany Jean Clement</a></li>
</ul>
</li>
<li id="menu-item-9845497" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-has-children menu-item-9845497"><a href="/life/travel/">Travel</a>
<ul class="sub-menu">
	<li id="menu-item-9845496" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-9845496"><a href="/life/outdoors/">Outdoors</a></li>
	<li id="menu-item-9849016" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-9849016"><a href="https://www.seattletimes.com/category/northwest-hikes/">Northwest Hikes</a></li>
	<li id="menu-item-9849020" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-9849020"><a href="https://www.seattletimes.com/category/travel-in-washington-state/">Washington</a></li>
	<li id="menu-item-9849019" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-9849019"><a href="https://www.seattletimes.com/category/travel-to-oregon/">Oregon</a></li>
	<li id="menu-item-9849017" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-9849017"><a href="https://www.seattletimes.com/category/travel-to-british-columbia/">B.C.</a></li>
	<li id="menu-item-9849018" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-9849018"><a href="https://www.seattletimes.com/category/travel-to-hawaii/">Hawaii</a></li>
</ul>
</li>
<li id="menu-item-9845477" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-has-children menu-item-9845477"><a href="/opinion/">Opinion</a>
<ul class="sub-menu">
	<li id="menu-item-9845551" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-9845551"><a href="/opinion/editorials/">Editorials</a></li>
	<li id="menu-item-9845552" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-9845552"><a href="/opinion/letters-to-the-editor/">Letters</a></li>
	<li id="menu-item-9848983" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-9848983"><a href="https://www.seattletimes.com/category/op-eds/">Op-Eds</a></li>
	<li id="menu-item-9848988" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-9848988"><a href="/author/david-horsey/">David Horsey</a></li>
	<li id="menu-item-9848985" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-9848985"><a href="/author/kate-riley/">Kate Riley</a></li>
	<li id="menu-item-9848987" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-9848987"><a href="/author/brier-dudley/">Brier Dudley</a></li>
	<li id="menu-item-12763164" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-12763164"><a href="/author/alex-fryer/">Alex Fryer</a></li>
	<li id="menu-item-12763158" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-12763158"><a href="/author/carlton-winfrey/">Carlton Winfrey</a></li>
	<li id="menu-item-15776053" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-15776053"><a href="/author/claudia-rowe/">Claudia Rowe</a></li>
	<li id="menu-item-16189364" class="menu-item menu-item-type-taxonomy menu-item-object-post_tag menu-item-16189364"><a href="https://www.seattletimes.com/tag/free-press/">Free Press</a></li>
</ul>
</li>
<li id="menu-item-9845540" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-9845540"><a href="/newsroom-staff/#news-columnists">Columnists</a>
<ul class="sub-menu">
	<li id="menu-item-9849057" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-9849057"><a href="/author/gene-balk-fyi-guy">FYI Guy</a></li>
	<li id="menu-item-9849058" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-9849058"><a href="/author/gabriel-campanario-seattle-sketcher/">Seattle Sketcher</a></li>
	<li id="menu-item-9849037" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-9849037"><a href="/author/danny-westneat/">Danny Westneat</a></li>
	<li id="menu-item-12182094" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-12182094"><a href="https://www.seattletimes.com/author/naomi-ishisaka/">Naomi Ishisaka</a></li>
	<li id="menu-item-12758926" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-12758926"><a href="/author/jon-talton/">Jon Talton</a></li>
</ul>
</li>
</ul><ul id="menu-all-sections-tier-2" class="all-sections-secondary"><li id="menu-item-16227602" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-16227602"><a href="https://www.bestinthepnw.com/">Best in the PNW</a></li>
<li id="menu-item-15840520" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-15840520"><a href="https://theticket.seattletimes.com">The Ticket</a></li>
<li id="menu-item-9849281" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-9849281"><a href="http://jobs.seattletimes.com/">Jobs</a></li>
<li id="menu-item-9849284" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-9849284"><a href="http://autos.seattletimes.com/">Autos</a></li>
<li id="menu-item-9849285" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-9849285"><a href="/explore/nwhomes/">Homes Listings</a></li>
<li id="menu-item-9849286" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-9849286"><a href="http://classifieds.seattletimes.com/">Classifieds</a></li>
<li id="menu-item-10203919" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-10203919"><a href="https://obituaries.seattletimes.com/">Paid Obituaries</a></li>
<li id="menu-item-16189463" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-16189463"><a href="/explore/">Explore</a></li>
<li id="menu-item-16189464" class="menu-item menu-item-type-taxonomy menu-item-object-section menu-item-16189464"><a href="/sponsored/">Sponsored Posts</a></li>
<li id="menu-item-9849290" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-9849290"><a href="http://company.seattletimes.com/store/">Seattle Times Store</a></li>
</ul><ul id="menu-all-sections-tier-3" class="all-sections-footer"><li id="menu-item-9849310" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-9849310"><a href="https://www.seattletimes.com/contact/">Contact</a></li>
<li id="menu-item-9849312" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-9849312"><a href="/help/">FAQs</a></li>
<li id="menu-item-9849313" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-9849313"><a href="https://secure.seattletimes.com/accountcenter/managesubscriptions">Subscriber Services</a></li>
<li id="menu-item-9849314" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-9849314"><a href="https://secure.seattletimes.com/accountcenter/replica">Print Replica</a></li>
<li id="menu-item-13602284" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-13602284"><a href="https://www.seattletimes.com/todays-times/">Today&#8217;s Paper</a></li>
<li id="menu-item-9849315" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-9849315"><a href="https://itunes.apple.com/us/app/seattle-times-mobile/id329502124">iOS App</a></li>
<li id="menu-item-9849318" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-9849318"><a href="https://play.google.com/store/apps/details?id=com.seattletimes.android.SeattleTimesMobileNews">Android App</a></li>
<li id="menu-item-17518590" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-17518590"><a href="https://www.seattletimes.com/latest/">Latest</a></li>
</ul></div></div>      </div>

      <div class="show-mobile">

        <div class="section-nav-popup">

          <div class="section-nav-popup-header">

            
            <a class="section-nav-button close" href="#">
              <svg class="icon-x icon-white icon">
                <use xlink:href="#icon-x"></use>
              </svg>
            </a>

          </div>

          <div class="section-nav-popup-container">
                      </div>

        </div>

      </div>

    </nav>

    <div class="secondary-nav-mobile">
      <div class="wrapper">
        <a href="#" class="section-title section-nav-button">404 Error</a>
        <nav class='header-utils'>
  <ul>
    <li class='user-link'><a href='/newsletters'>Newsletters</a></li>
    <li class='user-link'><a href='https://secure.seattletimes.com/accountcenter/' class='login st-return'>Log In</a></li>
    <li class='user-link'><a id='header-subscribe-link' href='/subscribe/signup-offers?subsource=voluntary' class='subscribe st-return'>Subscribe</a></li>
  </ul>
</nav>
      </div>
    </div>
    <div id="userMessagingTopOverlay" class="user-messaging animate"></div>
  </header>

  <div id="content-well" >
    <main id="main" class="site-main wrapper" role="main">

      <section class="content-well">
        <div class="wrapper">
          <div class="four-oh-four">

            <h2 class="font-xxlarge">Uff da!</h2>

            <h3 class="font-large">You’ve come to a dead end.</h3>

            <figure id="image-troll">
              <picture>
                <img src="https://www.seattletimes.com/wp-content/themes/st_refresh/img/fremont-troll-768.jpg"
                     srcset="https://www.seattletimes.com/wp-content/themes/st_refresh/img/fremont-troll-300.jpg 300w, https://www.seattletimes.com/wp-content/themes/st_refresh/img/fremont-troll-480.jpg 480w, https://www.seattletimes.com/wp-content/themes/st_refresh/img/fremont-troll-768.jpg  768w, https://www.seattletimes.com/wp-content/themes/st_refresh/img/fremont-troll-1560.jpg 1560w" sizes=" (max-width: 767px) calc(100vw - 40px), (max-width: 842px) calc(100vw - 60px) , 768px"/>
              </picture>
              <figcaption>Fremont Troll by Seattle Sketcher, <a href="/author/gabriel-campanario-seattle-sketcher/">Gabriel Campanario</a>.</figcaption>

            </figure>

            <p>The page you were looking for couldn’t be found, or may have been moved. Be sure to check your spelling in the address field in your browser.</p>

            <p>Here are some things you can do now:</p>

            <ul class="horizontal-list-menu">
              <li><a href="https://www.seattletimes.com/contact-us">Report a broken link</a></li>
              <li><a href="https://www.seattletimes.com">Visit the homepage</a></li>
            </ul>

            <form method="get" action="/search/?">
              <label>
                <span class="screen-reader-text">Search for:</span>
                <input name="query" placeholder="Search ..." type="search" class="search-field" title="Search for:">
              </label>
              <input type="submit" class="search-submit st-button" value="Search">
            </form>

            <p>Follow <a href="https://twitter.com/seattletimes/">@seattletimes</a> on Twitter or visit our <a href="https://www.facebook.com/seattletimes">Facebook page</a>.</p>
        </div>
    </main><!-- #main -->
  </div><!-- #content-well -->


</div>

 <script>
    var um = '<div class="GenericBar user-messaging-overlay overlay is-active" tabindex="-1" role="dialog" aria-labeledby="modalTitle"> \
        <div class="modal" role="document"> \
          <div class="modal-wrapper"> \
            <button type="button" class="close x-button" aria-label="Close"> \
              <i class="close-icon"></i> \
            </button> \
            <div class="copy-wrapper"> \
              <h1 class="u-sans u-off-white pr-1" id="modalTitle">Your browser is out of date</h1> \
              <p class="u-sans u-off-white pr-1">Stay secure and make sure you have the best reading experience possible by upgrading your browser!</p> \
              <a href="https://www.seattletimes.com/update-your-browser/" id="genericMessageButton" class="u-sans">Learn more<i class="icon-chevron-thin-right"></i></a> \
            </div> \
            <div class="logo-wrapper"> \
              <div class="st-logo"></div> \
            </div> \
          </div> \
        </div> \
      </div> \
      <style>.GenericBar.overlay{position:relative;opacity:0;-webkit-transition:1s all ease-in-out;-o-transition:1s all ease-in-out;transition:1s all ease-in-out}.GenericBar.overlay.is-active{opacity:1}.GenericBar .modal{width:100%;height:auto;padding:10px;background-color:#000;position:fixed;bottom:-100%;-webkit-transition:2s all ease-in-out;-o-transition:2s all ease-in-out;transition:2s all ease-in-out}@media screen and (min-width: 600px){.GenericBar .modal{padding:20px}}.GenericBar.is-active .modal{bottom:0}.GenericBar .modal-wrapper{position:relative;max-width:1030px;margin:0 auto}.GenericBar .copy-wrapper{text-align:center;width:calc(100% - 70px);margin:0 auto}@media screen and (min-width: 600px){.GenericBar .copy-wrapper{text-align:left;width:calc(100% - 40px);margin:0}}.GenericBar .logo-wrapper{position:absolute;left:-10px;top:-10px;z-index:-1;height:calc(100% + 20px);width:100%}@media screen and (min-width: 600px){.GenericBar .logo-wrapper{left:-20px;top:-20px;height:calc(100% + 40px)}}.GenericBar h1,.GenericBar p,.GenericBar a{font-size:15px;line-height:1.4;margin:0}@media screen and (min-width: 600px){.GenericBar h1,.GenericBar p,.GenericBar a{font-size:20px;line-height:1.1}}.GenericBar h1{font-weight:normal}@media screen and (min-width: 600px){.GenericBar h1{margin-bottom:0;font-weight:bold}}.GenericBar h1,.GenericBar a{display:block}@media screen and (min-width: 600px){.GenericBar h1,.GenericBar a{display:inline-block}}.GenericBar p{display:none}@media screen and (min-width: 600px){.GenericBar p{display:block}}.GenericBar a{color:#b85a22}@media screen and (min-width: 600px){.GenericBar a{font-weight:bold}}.GenericBar a:hover,.GenericBar a.hover,.GenericBar a:focus,.GenericBar a.focus{color:#d06723}.GenericBar .x-button{display:block;position:absolute;top:50%;right:0;margin-top:-12px;color:#f8f8f8}.GenericBar button.x-button{min-height:initial;line-height:normal;background-color:transparent;padding:0;border:none;height:24px;width:24px}.GenericBar button.x-button:hover,.GenericBar button.x-button.hover,.GenericBar button.x-button:focus,.GenericBar button.x-button.focus{color:#e0e0e0;background-color:transparent}.GenericBar .close-icon{position:absolute;left:0;top:0;width:24px;height:24px;opacity:.8}.GenericBar .close-icon:hover,.GenericBar .close-icon.hover,.GenericBar .close-icon:focus,.GenericBar .close-icon.focus{opacity:1}.GenericBar .close-icon:before,.GenericBar .close-icon:after{content:" ";position:absolute;left:12px;height:24px;width:2px;background-color:#f8f8f8}.GenericBar .close-icon:before{-webkit-transform:rotate(45deg);-ms-transform:rotate(45deg);transform:rotate(45deg)}.GenericBar .close-icon:after{-webkit-transform:rotate(-45deg);-ms-transform:rotate(-45deg);transform:rotate(-45deg)}.GenericBar .st-logo{height:120%;background-repeat:no-repeat;background-size:contain;background-image:url("data:image/svg+xml;charset=US-ASCII,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22400%22%20height%3D%22300%22%20viewBox%3D%220%200%20400%20300%22%3E%3Cg%20fill%3D%22%23fff%22%3E%3Cpath%20d%3D%22M148.445%2081.896c-14.142-19.86-42.73-47.343-69.81-47.343-18.254%200-26.78%2011.234-26.78%2020.462%200%2012.437%2010.532%2020.862%2037.613%2038.314%2053.66%2034.603%2095.387%2058.374%2095.387%20104.212%200%2047.845-51.354%2064.896-66.5%20100.804h-.903c-33.4-48.547-91.876-58.176-115.648-36.61L0%20260.432c3.008-21.865%2016.147-60.883%2047.943-60.883%2029.088%200%2067.502%2038.616%2091.174%2048.544%203.41%201.404%206.52.502%208.826-2.307%203.01-3.61%204.915-9.527%204.915-18.855%200-64.496-133.7-82.85-133.7-134.404%200-12.136%2011.133-34%2026.78-53.16C66.297%2014.293%2086.96%203.06%20109.427%203.06c34.805%200%2052.156%2026.078%2066.7%2026.078%206.12%200%2010.13-2.407%2013.94-7.522l3.71%203.11c-8.624%209.026-18.453%2019.458-27.08%2030.59l-1.304.904c-14.34%205.415-12.636%2019.357-16.95%2025.676%22%2F%3E%3Cpath%20d%3D%22M143.83%20227.734c0-57.27-135.305-75.228-135.305-135.308l-1.405.2c-9.73%2067.404%20123.27%2084.755%20135.207%20135.61l1.504-.502zM151.654%2084.504c-.5-7.824%201.706-15.948%207.724-22.268%206.82-7.22%2016.55-10.432%2032.798-10.432%2029.99%200%2082.95%2022.568%20129.39%2022.568%2040.52%200%2068.103-39.417%2078.436-60.28L395.59%201.653l-.702.1c-2.408%2017.353-17.453%2038.716-50.45%2038.716-31.497%200-93.382-24.07-125.778-24.07-46.74%200-69.108%2033.5-73.12%2061.482l5.416%207.422.698-.8zM303.61%2066.85h9.93v202.007h-9.93zM231.19%2068.757l5.116%203.11c-21.562%2015.846-38.515%2045.835-38.515%2083.047%200%2061.986%2036.01%20113.342%2094.084%20113.342%2033.5%200%2054.562-17.152%2064.994-34.004l.604.2%201.103%2014.745c-16.25%2014.746-51.253%2040.52-95.187%2040.52-68.205%200-109.528-46.738-109.528-108.322-.2-57.673%2039.82-93.382%2077.33-112.638%22%2F%3E%3Cpath%20d%3D%22M286.26%2066.35L260.58%2080.49c-15.948%208.727-19.258%2018.055-19.258%2035.707%200%2015.847%204.513%2042.728%204.513%2064.19%200%2021.967-4.513%2028.887-23.17%2036.812l3.108%205.817c12.338-5.618%2033.4-16.148%2047.242-24.978%2011.336-7.22%2013.24-11.232%2013.24-22.666v-69.51c0-22.567.5-29.488%204.814-35.606l-4.81-3.91z%22%2F%3E%3C%2Fg%3E%3C%2Fsvg%3E");opacity:0.15}</style>';
    var ua = window.navigator.userAgent.toLowerCase();
    var isIE = ua.indexOf('trident') != -1;
    if (isIE) {
      let div = document.createElement('div');
      div.innerHTML = um;
      document.body.appendChild(div);
    }
 </script>


  <footer class="global-footer">
    <div class="seattle-horizon">
      <span></span>
    </div>
    <div class="footer-top">
      <div class="wrapper">
        <ul class="footer-nav-primary">
          <li id="menu-item-42879" class="menu-item menu-item-type-taxonomy menu-item-object-post_format menu-item-has-children menu-item-42879"><a href="https://www.seattletimes.com/type/link/">COMPANY</a>
<ul class="sub-menu">
	<li id="menu-item-13213718" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-13213718"><a href="https://company.seattletimes.com/who-we-are/">About</a></li>
	<li id="menu-item-9487380" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-9487380"><a href="https://www.seattletimes.com/contact/">Contact</a></li>
	<li id="menu-item-13218017" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-13218017"><a href="https://company.seattletimes.com/careers/">Careers</a></li>
	<li id="menu-item-13213724" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-13213724"><a href="https://stux.wufoo.com/forms/permissions-and-licensing-request/">Permissions</a></li>
	<li id="menu-item-9619487" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-9619487"><a href="https://www.seattletimes.com/newsroom-staff/">Newsroom Staff</a></li>
</ul>
</li>
<li id="menu-item-13213729" class="menu-item menu-item-type-taxonomy menu-item-object-post_format menu-item-has-children menu-item-13213729"><a href="https://www.seattletimes.com/type/link/">COMMUNITY</a>
<ul class="sub-menu">
	<li id="menu-item-42808" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-42808"><a href="https://nie.seattletimes.com">Newspapers in Education</a></li>
	<li id="menu-item-42809" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-42809"><a href="https://ffn.seattletimes.com">Fund for Those in Need</a></li>
	<li id="menu-item-13213734" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-13213734"><a href="https://company.seattletimes.com/investigativefund/">Investigative Journalism Fund</a></li>
</ul>
</li>
<li id="menu-item-42880" class="menu-item menu-item-type-taxonomy menu-item-object-post_format menu-item-has-children menu-item-42880"><a href="https://www.seattletimes.com/type/link/">Advertise</a>
<ul class="sub-menu">
	<li id="menu-item-42817" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-42817"><a href="https://mediasolutions.seattletimes.com/">Media Solutions</a></li>
	<li id="menu-item-13148502" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-13148502"><a href="https://contentstudio.seattletimes.com/">ST Content Studio</a></li>
	<li id="menu-item-42825" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-42825"><a href="https://classifieds.seattletimes.com/">Classifieds</a></li>
	<li id="menu-item-42831" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-42831"><a href="https://jobs.seattletimes.com/employer-home">Jobs</a></li>
	<li id="menu-item-14511702" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-14511702"><a href="https://autos.seattletimes.com/">Autos</a></li>
	<li id="menu-item-42830" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-42830"><a href="https://obituaries.seattletimes.com/select-notice-type">Obituaries</a></li>
</ul>
</li>
<li id="menu-item-42874" class="menu-item menu-item-type-taxonomy menu-item-object-post_format menu-item-has-children menu-item-42874"><a href="https://www.seattletimes.com/type/link/">SUBSCRIPTION</a>
<ul class="sub-menu">
	<li id="menu-item-42839" class="st-return menu-item menu-item-type-custom menu-item-object-custom menu-item-42839"><a href="/subscribe/signup-offers/?subsource=voluntary">Subscribe</a></li>
	<li id="menu-item-42843" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-42843"><a href="https://secure.seattletimes.com/accountcenter/">My Account</a></li>
	<li id="menu-item-42842" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-42842"><a href="https://replica.seattletimes.com/">Print Replica Login</a></li>
	<li id="menu-item-13602288" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-13602288"><a href="https://www.seattletimes.com/todays-times/">Today&#8217;s Paper</a></li>
	<li id="menu-item-5522514" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-5522514"><a href="https://company.seattletimes.com/mobile/">Mobile Apps</a></li>
	<li id="menu-item-42783" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-42783"><a href="https://www.seattletimes.com/help/">Help/FAQ</a></li>
</ul>
</li>
<li id="menu-item-13213820" class="menu-item menu-item-type-taxonomy menu-item-object-post_format menu-item-has-children menu-item-13213820"><a href="https://www.seattletimes.com/type/link/">CONNECT</a>
<ul class="sub-menu">
	<li id="menu-item-13213771" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-13213771"><a href="https://www.seattletimes.com/newsletters/">Manage Newsletters</a></li>
	<li id="menu-item-42875" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-42875"><a target="_blank" rel="noopener" href="https://www.facebook.com/seattletimes">Facebook</a></li>
	<li id="menu-item-42876" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-42876"><a target="_blank" rel="noopener" href="https://twitter.com/seattletimes">Twitter</a></li>
	<li id="menu-item-13213809" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-13213809"><a href="https://www.seattletimes.com/rss-feeds/">RSS</a></li>
	<li id="menu-item-14063754" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-14063754"><a href="https://seattletimes.newsbank.com">Newspaper Archive Access</a></li>
</ul>
</li>
        </ul>
      </div>
    </div>

    
<div class="footer-btm">
  <div class="wrapper">
    <section class="footer-copyright">
      <a href="/notices/copyright.html">Copyright &copy; 2025 The Seattle Times</a> |
      <a href="/notices/privacy.html">Privacy Statement</a> |
      <a href="/notices/privacy.html#california">Notice At Collection</a> |
      <a href="/notices/privacy.html#donotsell">Do Not Sell My Personal Information</a> |
      <a href="/notices/terms.html">Terms of Service</a>
    </section>
  </div>
</div>

  </footer>

<div class="modals">
  <div class="st-paywall__overlay-messaging"></div>
  <div id="message-container"></div>
  <div id="userMessagingOverlay" class="user-messaging"></div>
</div>
<div id='ccpa-test'>
  <script>
  window.SEATIMESCO.privacy = {
    ccpaLoaded: false
  };
  </script>
  <script id='finish-ccpa' type='text/plain' class='optanon-category-SN'>
    window.SEATIMESCO.privacy.ccpaLoaded = true;
  </script>
</div>
<div class="footer-scripts">

  <script type='text/javascript' id='st-spruce-bundle-script' src='https://www.seattletimes.com/wp-content/plugins/st-spruce-app/dist/st-spruce-bundle.js?ver=1739903191' defer></script><script type='text/javascript' id='st-spruce-admin-script' src='https://www.seattletimes.com/wp-content/plugins/st-spruce-deuce/dist/st-spruce-app.js?ver=1739903237' defer></script><script type="text/javascript" id="st-app-js-extra">
/* <![CDATA[ */
var globalStub = [];
var SEATIMESCO = SEATIMESCO || {};
 SEATIMESCO.paywall = SEATIMESCO.paywall || {"contentMetered":false,"pageExcluded":false,"configs":[{"target":"all","config":"https:\/\/www.seattletimes.com\/paywallconfig\/stdotcom\/"},{"target":"privateMode=on","config":"https:\/\/www.seattletimes.com\/paywallconfig\/mmtest\/"},{"target":"STSegment=mmtest","config":"https:\/\/www.seattletimes.com\/paywallconfig\/mmtest\/"},{"target":"STSegment=incognito","config":"https:\/\/www.seattletimes.com\/paywallconfig\/incognito\/"},{"target":"_matherSegments=MATHER_PW_GROUPB_20240702","config":"https:\/\/www.seattletimes.com\/paywallconfig\/paywall2\/"}],"overlayEnabled":"","overlayData":{"headerLinkText":"Go to homepage","headerLink":"https:\/\/www.seattletimes.com\/","headline":"Get 4 weeks of unlimited digital access for $1","headlineMobile":"","subscribeButtonText":"Subscribe now","subscribeButtonLink":"https:\/\/secure.seattletimes.com\/accountcenter\/subscribe\/?campaign=pw-overlay&amp;subsource=paywall","ctaDescription":"Cancel anytime","footerMessageOne":"Looking for a print subscription?","footerMessageOneLinkText":"View more offers","footerMessageOneLink":"https:\/\/www.seattletimes.com\/subscribe\/signup-offers\/?pw=overlay&amp;subsource=paywall","footerMessageTwo":"Already a subscriber?","footerMessageTwoLinkText":"Log in","footerMessageTwoLink":"https:\/\/secure.seattletimes.com\/accountcenter\/"}}; 
        window.SEATIMESCO.browser = window.SEATIMESCO.browser || {};
        window.SEATIMESCO.browser.privacy = window.SEATIMESCO.browser.privacy || {};
        window.SEATIMESCO.browser.privacy.detectionEnabled = true;
        window.SEATIMESCO.browser.privacy.doNotTrack = 0;

        window.SEATIMESCO.userMessaging = window.SEATIMESCO.userMessaging || {};
        window.SEATIMESCO.userMessaging.ab = {};
        window.SEATIMESCO.userMessaging.ab.detectionEnabled = true;
        ;
/* ]]> */
</script>
<script type='text/javascript' id='st-app-script' src='https://www.seattletimes.com/wp-content/themes/st_refresh/js/bundle.min.js?ver=1739903192' defer></script><script type='text/javascript' id='st-sitewide-script' src='https://www.seattletimes.com/wp-content/themes/st_refresh/js/site-wide/dist/st-sitewide-bundle.js?ver=1739903192' defer></script><script type='text/javascript' id='ads_script-script' src='https://www.seattletimes.com/wp-content/plugins/st-advertising/dist/st-advertising-bundle.js?ver=1739903191' defer></script>
  
</div>



<script>
window.aax = window.aax || {};
window.aax.cmd = window.aax.cmd || [];

window.aax.cmd.push(function () {
if (window.aax.getAbpStatus()) {
  window.googletag = window.googletag || {};
  window.googletag.cmd = window.googletag.cmd || [];
  window.googletag.cmd.push(function () {
    googletag.pubads().refresh();
  });
}
});

window.aax.cmd.push(function() {
  window.aax.addEventListener('slotRenderEnded', function (event) {
    var slotElementId = event.dfpDetails.slot.getSlotElementId();
    var slotDiv = document.getElementById(slotElementId);
    slotDiv.style['width'] = '300px';
  });
});
</script>
</body>
</html>




<!--
Performance optimized by W3 Total Cache. Learn more: https://www.boldgrid.com/w3-total-cache/

Object Caching 29/40 objects using Memcached

Served from: www.seattletimes.com @ 2025-02-21 00:16:46 by W3 Total Cache
-->